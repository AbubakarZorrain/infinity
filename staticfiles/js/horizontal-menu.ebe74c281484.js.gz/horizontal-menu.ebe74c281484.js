// For horizontal menu 1
$(".horizontal-menu .navbar.horizontal-layout .navbar-menu-wrapper .navbar-toggler").on("click", function() {
  $(".horizontal-menu .navbar.horizontal-layout .nav-bottom").toggleClass("d-block");
});

// For horizontal menu 2
$(".horizontal-menu-2 .navbar.horizontal-layout-2 .navbar-menu-wrapper .navbar-toggler").on("click", function() {
  $(".horizontal-menu-2 .navbar.horizontal-layout-2 .nav-bottom").toggleClass("header-toggled");
});
